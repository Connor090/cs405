// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
// edited by Connor Holohan 1/18/26

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;


  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  std::cin.getline(user_input, 20);   // Capping user input at 20, more correctly this should be 19
  if (std::cin.fail()) { // if the input is over we let the user know that they entered an invalid number.

	  std::cout << "Value entered is over 20: ";
  }
  
  else {
	  std::cout << "You entered: " << user_input << std::endl; // if the number entered is correct we output like previously
	  std::cout << "Account Number = " << account_number << std::endl;
  }
  
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
